#final IT assignment question 1
# Annabelle Chen   u3216405


def main():
    while True:
        try:
            num = int(input("\nEnter a number between 1 to 10: "))
        except ValueError:
            print("That is not an integer, please try again")
        except ZeroDivisionError:
            print("Oops, you entered zero :0( ")
        else:
            try:
                if num >=0 and num <=10:
                    print("The reciprocal is of your number is: ",(1/num))
                    break
                else:
                    print("not between 1 and 10")
            except ZeroDivisionError:
                print(num," oops you entered 0!")
           
main()
