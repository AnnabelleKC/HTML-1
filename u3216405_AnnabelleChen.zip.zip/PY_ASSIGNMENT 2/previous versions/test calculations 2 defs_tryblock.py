### Author: Annabelle Chen u3216405
### Date created: 22 Oct 2020
### Date last changed: 01 Nov 2020

### "Australian City Pool Price Calculator"
### This is my program to take dimensions of a pool, and calculate the cost of constructing the pool based on the city it is built in.
### Input: This will take height, width, and length from the user's keyboard
### Output: total volume and a final fee

def main(): # this is where the menu, and city inputs are processed
    print("\n\t\t========================")
    print("\n      ||    Australian City Pool Price Calculator   ||")
    print(" 1)  Alice Springs")
    print(" 2)  Canberra")
    print(" 3)  Melbourne")
    print(" 4)  Brisbane")
    print(" 5)  Exit")  
    
    while True: #this will loop the menu/city input screen until a valid city is entered
        try:
            cities=['Alice Springs','Canberra','Melbourne','Brisbane','Exit']
            selectcity = input("Enter the name of the city to proceed    OR   enter Exit: ").strip()
            print("the option you chose is: ", selectcity)
            if selectcity not in cities:
                print(selectcity," is not a city please try again.\n")
                main()
            break
        except NameError as e:
            print("not a city",e)
            main()

# these if statements will go to a city's calculation depending on the city entered previously
    if selectcity == 'Alice Springs':
        AliceSprings()
    if selectcity == 'Canberra':
        Canberra()
    if selectcity == 'Melbourne':
        Melbourne()
    if selectcity == 'Brisbane':
        Brisbane()
    if selectcity == 'Exit':
        print("----Ending Program----")

def AliceSprings(): #this function will ask for dimensions and process volume and the cost of a pool
    height = float(input("Please enter the pool height: "))
    length = float(input("Please enter the pool length: "))
    width = float(input("Please enter the pool width: "))
    volume = float(height*length*width)
    poolcost = volume*1.2
    if height<=6 and height>0:       #if the input is not within the business rules, it will loop back to asking for them again
        if length<=60 and length>0:
            if width<=30 and width>0: 
                print("The dimension of your pool is: ",volume)                   
                print("The final cost of constructing your pool is: ${0:>,.2f}".format(poolcost))
                main()
            else:
                print ("width is out of bounds, Please try again\n")
                AliceSprings()
        else:
            print ("length is out of bounds, Please try again\n")
            AliceSprings()
    else:
        print ("Height is out of bounds, Please try again\n")
        AliceSprings()
    
def Canberra():
    height = float(input("Please enter the pool height: "))
    length = float(input("Please enter the pool length: "))
    width = float(input("Please enter the pool width: "))
    volume = float(height*length*width)
    poolcost = float(volume*1.8)
    if height<=6 and height>0:  
        if length<=60 and length>0:
            if width<=30 and width>0: 
                print("The dimension of your pool is: ",volume)                   
                print("The final cost of constructing your pool is: ${0:>,.2f}".format(poolcost))
                main()
            else:
                print ("width is out of bounds, Please try again\n")
                Canberra()
        else:
            print ("length is out of bounds, Please try again\n")
            Canberra()
    else:
        print ("Height is tout of bounds, Please try again\n")
        Canberra()
        
def Melbourne():
    height = float(input("Please enter the pool height: "))
    length = float(input("Please enter the pool length: "))
    width = float(input("Please enter the pool width: "))
    volume = float(height*length*width)
    poolcost = float(volume*2)
    if height<=6 and height>0:  
        if length<=60 and length>0:
            if width<=30 and width>0: 
                print("The dimension of your pool is: ",volume)                   
                print("The final cost of constructing your pool is: ${0:>,.2f}".format(poolcost))
                main()
            else:
                print ("width is out of bounds, Please try again\n")
                Melbourne()
        else:
            print ("length is out of bounds, Please try again\n")
            Melbourne()
    else:
        print ("Height is out of bounds, Please try again\n")
        Melbourne()
    
def Brisbane(): 
    height = float(input("Please enter the pool height in meters: "))
    length = float(input("Please enter the pool length in meters: "))
    width = float(input("Please enter the pool width in meters: "))
    volume = float(height*length*width)
    poolcost = float(volume*1.2)
    if height<=6 and height>0: ##need this for all inputs+ put tryexceptblcok aorund it
        if length<=60 and length>0:
            if width<=30 and width>0: 
                print("The dimension of your pool is: ",volume)                   
                print("The final cost of constructing your pool is: ${0:>,.2f}".format(poolcost))
                main()
            else:
                print ("width is out of bounds, Please try again\n")
                Brisbane()
        else:
            print ("length is out of bounds, Please try again\n")
            Brisbane()
    else:
        print ("Height is out of bounds, Please try again\n")
        Brisbane()


main()  #this will call the main function/menu




