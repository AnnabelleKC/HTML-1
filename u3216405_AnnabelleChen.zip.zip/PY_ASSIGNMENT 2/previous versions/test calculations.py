###test calculations with a list and input values
def Canberra():
    CB=1.8
def Melbourne():
    Melb=2
def Brisbane():
    Bris=1.2
    
cities=['Alice Springs','Canberra','Melbourne','Brisbane','Exit']
print(cities)

while True:
    try:
        selectcity = input("select a city")
        print("the city you chose is: ", selectcity)
        break
    except:
        print("not a city")

if selectcity == 'Alice Springs':
    height = float(input("Please enter the pool height: "))
    length = float(input("Please enter the pool length: "))
    width = float(input("Please enter the pool width: "))
    AliceSprings = 1.2
    volume = height*length*width
    poolcost = volume* AliceSprings
    print(poolcost)
    if selectcity == 'Canberra':
        Canberra()
        if selectcity == 'Melbourne':
            Melbourne()
            if selectcity == 'Brisbane':
                Brisbane()
                if selectcity == 'Exit':
                    print("----Ending Program----")
                   
