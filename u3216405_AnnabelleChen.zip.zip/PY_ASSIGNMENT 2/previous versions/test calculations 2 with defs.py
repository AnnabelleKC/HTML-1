###test calculations with a list and input values
def AliceSprings(AS):
    height = float(input("Please enter the pool height: "))
    length = float(input("Please enter the pool length: "))
    width = float(input("Please enter the pool width: "))
    volume = float(height*length*width)
    poolcost = float(volume* AliceSprings)
    print("The dimensions of your pool are: ",volume)                   
    print("The final cost of constructing your pool are: (0:>2s)".format(poolcost))
    
def Canberra(CB):
    height = float(input("Please enter the pool height: "))
    length = float(input("Please enter the pool length: "))
    width = float(input("Please enter the pool width: "))
    volume = float(height*length*width)
    poolcost = float(volume*CB)
    print("The dimensions of your pool are: ",volume)                   
    print("The final cost of constructing your pool are: $",poolcost)
    
def Melbourne(Melb):
    height = float(input("Please enter the pool height: "))
    length = float(input("Please enter the pool length: "))
    width = float(input("Please enter the pool width: "))
    volume = float(height*length*width)
    poolcost = float(volume*Melb)
    print("The dimensions of your pool are: ",volume)                   
    print("The final cost of constructing your pool are: (0:>2s)".format(poolcost))
    
def Brisbane(Bris): 
    height = float(input("Please enter the pool height in meters: "))
    length = float(input("Please enter the pool length in meters: "))
    width = float(input("Please enter the pool width in meters: "))
    volume = float(height*length*width)
    poolcost = float(volume*Bris)
    if height<=6 and height>0: ##need to do this for length + width too + put a tryexcept blcok aorund it
        print("The dimension of your pool is: ",volume)                   
        print("The final cost of constructing your pool are: (0:>0s)".format(poolcost))
    
cities=['Alice Springs','Canberra','Melbourne','Brisbane','Exit']
print(cities)

while True:
    try:
        selectcity = input("select a city: ")
        print("the option you chose is: ", selectcity)
        break
    except:
        print("not a city")

if selectcity == 'Alice Springs':
    AliceSprings(1.2)
if selectcity == 'Canberra':
    Canberra(1.8)
if selectcity == 'Melbourne':
    Melbourne(2)
if selectcity == 'Brisbane':
    Brisbane(1.2)
if selectcity == 'Exit':
    print("----Ending Program----")


