## stage 3  

### Author: Annabelle Chen u3216405
### Date created: 28 Oct 2020
### Date last changed: 01 Nov 2020

### "Australian City Pool Price Calculator (with GUI + file reader)"
### This is my program to take dimensions of a pool, and calculate the cost of constructing the pool based on the city it is built in.
### Input: This will take height, width, and length from the user's keyboard, and read in city names
### Output: a final fee

from tkinter import *
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 300

window = Tk() 
window.title("Australian City Pool Price Calculator")

# to put a yellow background colour:
canvas = Canvas(window, width = CANVAS_WIDTH, height = CANVAS_HEIGHT, bg = "yellow")
canvas.grid(row=0, column=0, columnspan=10, rowspan=9)

def AS():
    h = eval(height.get())
    l = eval(length.get())
    w = eval(width.get())
    totalvolume=h*l*w
    fee = totalvolume*1.2
    if h<=6 and h>0:     #to apply the business rules for the program inputs
        if l<=60 and l>0:
            if w<=30 and w>0: 
                result.set(str(fee))
            else:
                print ("width is out of bounds, Please try again\n")
                close_window()
        else:
            print ("length is out of bounds, Please try again\n")
            close_window()
    else:
        print ("Height is tout of bounds, Please try again\n")
        close_window()
    
    
def CB():
    h = eval(height.get())
    l = eval(length.get())
    w = eval(width.get())
    totalvolume=h*l*w
    fee = totalvolume*1.8
    if h<=6 and h>0:  
        if l<=60 and l>0:
            if w<=30 and w>0: 
                result.set(str(fee))
            else:
                print ("width is out of bounds, Please try again\n")
                close_window()
        else:
            print ("length is out of bounds, Please try again\n")
            close_window()
    else:
        print ("Height is tout of bounds, Please try again\n")
        close_window()
    
def Melb():
    h = eval(height.get())
    l = eval(length.get())
    w = eval(width.get())
    totalvolume=h*l*w
    fee = totalvolume*2
    if h<=6 and h>0:  
        if l<=60 and l>0:
            if w<=30 and w>0: 
                result.set(str(fee))
            else:
                print ("width is out of bounds, Please try again\n")
                close_window()
        else:
            print ("length is out of bounds, Please try again\n")
            close_window()
    else:
        print ("Height is tout of bounds, Please try again\n")
        close_window()
    
def Bris():
    AS()
    
def close_window():  #ends program/kills window
    window.destroy()

def CityList(choose): #for the listbox function to select a city
    choosecity=city1.get(city1.curselection()) #what user chose from the list
    if choosecity == "Alice Springs":
        AS()
    elif choosecity =="Canberra":
        CB()
    elif choosecity =="Melbourne":
        Melb()
    elif choosecity =="Brisbane":
        Bris()
        
def readfile():        
    infile = open("externalfile.txt","r")
    line=infile.readline()
    while line !="":
        listLine = tuple()
        listLine = (line.strip()).split(",")
        cities.append(listLine)
        line = infile.readline()
    infile.close()

def display():
    item1=""
    for item in cities:
        item1 +=item[0]+"\n"
    city1.set(item1)
    

   
# Labels
firstlabel = Label(window, text="Height\r(metres):")  #to show what the entry widgets are for
firstlabel.grid(row=0, column =0)

seclabel = Label(window, text="Length\n(metres):")
seclabel.grid(row=0, column =1)

thirdlabel = Label(window, text="Width\n(metres):")
thirdlabel.grid(row=0, column =2)

fourthlabel = Label(window, text="Selected\nCity:\n")
fourthlabel.grid(row=2, column =1)

fifthlabel = Label(window, text="Pool Fee: ($)\n")
fifthlabel.grid(row=3, column =1)

# Entry Widgets
height = StringVar()
inheight = Entry(window, width=5, textvariable=height)  #get input from user 
inheight.grid(row=1, column =0)

length = StringVar()
inlength = Entry(window, width=5, textvariable=length)    
inlength.grid(row=1, column =1)

width = StringVar()
inwidth = Entry(window, width=5, textvariable=width)    
inwidth.grid(row=1, column =2)

result = StringVar()
inresult= Entry(window, width=15, state = 'readonly', textvariable=result)
inresult.grid(row=4,column=0, columnspan = 3, padx=9, pady=4)

# Buttons  
Calculate = Button(window, width=5, text='Calculate\nPool Fee', command=CityList)
Calculate.grid(row=6, column =0, padx=12, pady=4)

Exitbutton = Button(window, width=5, text='Exit', command=close_window)
Exitbutton.grid(row=6, column =2, padx=8, pady=4)

btnDisplay = Button(window, text="City options", command=display)
btnDisplay.grid(row=1, column=4, padx=30,pady=15)

scroller = Scrollbar(window, orient=VERTICAL)
scroller.grid(row=3, column=5, padx=30,pady=15, sticky=NS)

city1TXT=StringVar()
city1 = Listbox(window, width=10,height=5,listvariable = city1TXT, yscrollcommand=scroller.set)
city1.grid(row=2, column=4, padx=30,pady=15)

readfile()
    

window.mainloop() 
